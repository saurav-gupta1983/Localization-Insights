ASP.NET AJAX Control Toolkit Website Project

========================================================

You're now ready to start using the AJAX Control Toolkit.

This project is ready to use.  To use an AJAX Control Toolkit control, use the "ajaxToolkit" prefix.

Example:

    <ajaxToolkit:ConfirmButtonExtender />

To learn more about the AJAX Control Toolkit, visit:

    http://ajax.asp.net/ajaxtoolkit/
