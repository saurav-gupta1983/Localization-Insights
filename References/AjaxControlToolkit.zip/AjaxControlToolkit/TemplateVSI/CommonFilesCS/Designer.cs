using System.Web.UI.WebControls;
using System.Web.UI;

namespace $rootnamespace$
{
    class $baseitemname$Designer : AjaxControlToolkit.Design.ExtenderControlBaseDesigner<$baseitemname$Extender> {
    
       
    }
}
