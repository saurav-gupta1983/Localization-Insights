using System;
using System.Collections.Generic;
using System.Text;

namespace AjaxControlToolkit
{
    public enum BoxSide
    {
        Top = 0,
        Right = 1,
        Bottom = 2,
        Left = 3
    }
}
